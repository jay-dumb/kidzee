package com.jay.kidzeee1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

public class LearnNumber extends AppCompatActivity {

    ImageView Back;
    ImageView one, two, three, four, five, six, seven, eight, nine, ten, eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, eighteen, nineteen, twenty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn_number);


        Back = findViewById(R.id.LearnNumberBack);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);
        ten = findViewById(R.id.ten);
        eleven = findViewById(R.id.eleven);
        twelve = findViewById(R.id.twelve);
        thirteen = findViewById(R.id.thirteen);
        fourteen = findViewById(R.id.fourteen);
        fifteen = findViewById(R.id.fifteen);
        sixteen = findViewById(R.id.sixteen);
        seventeen = findViewById(R.id.seventeen);
        eighteen = findViewById(R.id.eighteen);
        nineteen = findViewById(R.id.nineteen);
        twenty = findViewById(R.id.twenty);


        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LearnNumber.super.onBackPressed();
            }
        });
        
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "one", Toast.LENGTH_SHORT).show();

                YoYo.with(Techniques.Hinge)
                        .duration(700)
                        .repeat(1)
                        .playOn(findViewById(R.id.one));
            }
        });
        
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "two", Toast.LENGTH_SHORT).show();


                YoYo.with(Techniques.Flash  )
                        .duration(700)
                        .repeat(1)
                        .playOn(findViewById(R.id.two));
            }
        });
        
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "three", Toast.LENGTH_SHORT).show();

                YoYo.with(Techniques.SlideInUp)
                        .duration(700)
                        .repeat(1)
                        .playOn(findViewById(R.id.three));
            }
        });
        
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "four", Toast.LENGTH_SHORT).show();

                YoYo.with(Techniques.FlipInX)
                        .duration(700)
                        .repeat(1)
                        .playOn(findViewById(R.id.four));
            }
        });
        
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "five", Toast.LENGTH_SHORT).show();

                YoYo.with(Techniques.BounceInUp)
                        .duration(700)
                        .repeat(1)
                        .playOn(findViewById(R.id.five));
            }
        });
        
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "six", Toast.LENGTH_SHORT).show();
            }
        });
        
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "seven", Toast.LENGTH_SHORT).show();
            }
        });
        
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "eight", Toast.LENGTH_SHORT).show();
            }
        });
        
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "nine", Toast.LENGTH_SHORT).show();
            }
        });
        
        ten.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "ten", Toast.LENGTH_SHORT).show();
            }
        });
        
        eleven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "eleven", Toast.LENGTH_SHORT).show();
            }
        });
        
        twelve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "twelve", Toast.LENGTH_SHORT).show();
            }
        });
        
        thirteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "thirteen", Toast.LENGTH_SHORT).show();
            }
        });
        
        fourteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "fourteen", Toast.LENGTH_SHORT).show();
            }
        });
        
        fifteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "fifteen", Toast.LENGTH_SHORT).show();
            }
        });
        
        sixteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "sixteen", Toast.LENGTH_SHORT).show();
            }
        });
        
        seventeen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "seventeen", Toast.LENGTH_SHORT).show();
            }
        });
        
        eighteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "eighteen", Toast.LENGTH_SHORT).show();
            }
        });
        
        nineteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "nineteen", Toast.LENGTH_SHORT).show();
            }
        });
        
        twenty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnNumber.this, "twenty", Toast.LENGTH_SHORT).show();
            }
        });

    }
}