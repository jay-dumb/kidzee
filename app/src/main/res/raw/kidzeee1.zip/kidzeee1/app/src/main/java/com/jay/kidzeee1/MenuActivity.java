package com.jay.kidzeee1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MenuActivity extends AppCompatActivity {


    CardView Numbers,Abc,Quiz,Pair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Numbers = findViewById(R.id.cardViewNumbers);
        Abc = findViewById(R.id.cardViewAbc);
        Quiz = findViewById(R.id.cardViewQuiz);
        Pair = findViewById(R.id.cardViewPair);



        Numbers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MenuActivity.this, LearnNumber.class));
            }
        });
        
        Abc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MenuActivity.this, LearnAbc.class));
            }
        });
        
        Quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MenuActivity.this, Quiz_activity.class));

            }
        });
        
        Pair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MenuActivity.this, "PAir", Toast.LENGTH_SHORT).show();
            }
        });


    }
}