package com.jay.kidzeee1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class LearnAbc extends AppCompatActivity {


    ImageView Back;
    ImageView a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn_abc);


        Back = findViewById(R.id.LearnAbcBack);
        a = findViewById(R.id.A);
        b = findViewById(R.id.B);
        c = findViewById(R.id.C);
        d = findViewById(R.id.D);
        e = findViewById(R.id.E);
        f = findViewById(R.id.F);
        g = findViewById(R.id.G);
        h = findViewById(R.id.H);
        i = findViewById(R.id.I);
        j = findViewById(R.id.J);
        k = findViewById(R.id.K);
        l = findViewById(R.id.L);
        m = findViewById(R.id.M);
        n = findViewById(R.id.N);
        o = findViewById(R.id.O);
        p = findViewById(R.id.P);
        q = findViewById(R.id.Q);
        r = findViewById(R.id.R);
        s = findViewById(R.id.S);
        t = findViewById(R.id.T);
        u = findViewById(R.id.U);
        v = findViewById(R.id.V);
        w = findViewById(R.id.W);
        x = findViewById(R.id.X);
        y = findViewById(R.id.Y);
        z = findViewById(R.id.Z);


        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LearnAbc.super.onBackPressed();
            }
        });
        
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "A", Toast.LENGTH_SHORT).show();
            }
        });
        
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "B", Toast.LENGTH_SHORT).show();
            }
        });
        
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "C", Toast.LENGTH_SHORT).show();
            }
        });
        
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "D", Toast.LENGTH_SHORT).show();
            }
        });
        
        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "E", Toast.LENGTH_SHORT).show();
            }
        });
        
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "F", Toast.LENGTH_SHORT).show();
            }
        });
        
        g.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "G", Toast.LENGTH_SHORT).show();
            }
        });
        
        h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "H", Toast.LENGTH_SHORT).show();
            }
        });
        
        i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "I", Toast.LENGTH_SHORT).show();
            }
        });
        
        j.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "J", Toast.LENGTH_SHORT).show();
            }
        });
        
        k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "K", Toast.LENGTH_SHORT).show();
            }
        });
        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "L", Toast.LENGTH_SHORT).show();
            }
        });
        m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "M", Toast.LENGTH_SHORT).show();
            }
        });
        n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "N", Toast.LENGTH_SHORT).show();
            }
        });
        o.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "O", Toast.LENGTH_SHORT).show();
            }
        });
        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "P", Toast.LENGTH_SHORT).show();
            }
        });
        q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "Q", Toast.LENGTH_SHORT).show();
            }
        });
        
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "R", Toast.LENGTH_SHORT).show();
            }
        });
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "S", Toast.LENGTH_SHORT).show();
            }
        });
        
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "T", Toast.LENGTH_SHORT).show();
            }
        });
        
        u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "U", Toast.LENGTH_SHORT).show();
            }
        });
        
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "V", Toast.LENGTH_SHORT).show();
            }
        });
        
        w.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "W", Toast.LENGTH_SHORT).show();
            }
        });
        
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "X", Toast.LENGTH_SHORT).show();
            }
        });
        
        y.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "Y", Toast.LENGTH_SHORT).show();
            }
        });
        
        z.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LearnAbc.this, "Z", Toast.LENGTH_SHORT).show();
            }
        });
        
    }
}